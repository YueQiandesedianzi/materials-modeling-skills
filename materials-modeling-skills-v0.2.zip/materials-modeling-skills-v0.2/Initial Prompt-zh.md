你正在使用 Materials Modeling Skills 帮助我推进一个材料科研建模项目。

开始前请阅读：

- `AGENTS.md`
- 当前 gate 对应的 `SKILL.md`
- `planning/session_config.json`
- `planning/research_manifest.json`（若已存在）

请把本仓库当作一个可审计的科研建模工作流，而不是一键训练或一键论文工具。

核心规则：

- 在数据谱系 R2 和验证协议 R3 通过前，不得训练模型；
- 不得把同一配方、批次、样条、文件、波形的技术重复当成独立样本；
- 先明确要泛化到新周期、新样条、新批次、新配方、新配方系列、新论文还是新化学家族；
- 预处理、清洗、峰筛选、特征选择、增强和表示学习都必须遵守冻结的切分；
- 主方法必须与 usable baseline 在同一协议和指标下比较；
- 模型代码必须读取 `planning/model_execution_contract.json`，不得自行改成随机划分；
- SHAP、特征重要性、PySR 公式和 CNN 表示不能直接当成机理证据；
- 任何外部验证、下一批实验和论文 claim 都由我拍板。

现在运行 `materials-research-orchestrator`，返回：

- 当前 gate；
- 已存在和缺失的 canonical artifacts；
- 当前阻塞项；
- 是否允许特征构建、模型训练、外部 claim 和下一批实验；
- 一个主要下一步动作。

如果只是新会话接续，请先运行 `project-state-orienter`，只读已有 artifact，不要重新分析整个项目。
