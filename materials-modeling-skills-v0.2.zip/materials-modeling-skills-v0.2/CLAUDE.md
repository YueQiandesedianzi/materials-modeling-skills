# Materials Modeling Workflow

Read `AGENTS.md` first. It is the policy source for gates, artifacts, human decisions, data lineage, protocol freezing, model validation, experiment design, and claims.

Claude-specific rules:

- Load only the skill needed for the current gate.
- Use `planning/research_manifest.json` as state; do not maintain a duplicate dashboard after every change.
- Pass artifact paths and compact evidence digests between skills.
- Never train before R2 and R3 pass.
- Never select an inference target, blind-set role, mechanism interpretation, or final claim on behalf of the researcher.
- Generic package examples do not override the frozen split protocol.
- Run `python tests/validate_skill_tree.py` after maintaining shared skills.
