---
name: waveform-cycle-curator
description: Segment, quality-score, align, curate, and register waveform cycles or peaks for materials sensing and TENG projects while preserving file/specimen/formulation ancestry and preventing cycle-level leakage and augmentation contamination.
metadata:
  version: "0.1"
---

# Purpose

Convert raw waveform files into traceable cycle-level evidence without inflating independent sample count or leaking related cycles across validation boundaries.

# Preconditions

- Raw waveform files and acquisition metadata exist.
- Expected period/peak structure is known or can be estimated without using held-out target labels.
- Sample/formulation identities are available or unresolved status is explicit.

# Workflow

1. Inventory files, channels, sampling rate, acquisition settings, and parent sample IDs.
2. Detect candidate cycles/peaks using a documented rule.
3. Compute quality indicators:
   - completeness and expected duration;
   - clipping/saturation;
   - baseline drift;
   - missing segments;
   - signal-to-noise;
   - peak count and polarity;
   - temporal alignment residual;
   - shape anomaly relative to training/reference data.
4. Separate automatic facts from human acceptance judgments.
5. Save raw-index boundaries so every curated cycle reconstructs from the source file.
6. Apply baseline correction, resampling, alignment, normalization, or denoising only under documented rules.
7. Register parent file, measurement, specimen, batch, formulation, and series IDs.
8. Define augmentation recipes; augmented children inherit parent groups and remain in the same fold.
9. Produce raw-waveform and engineered-feature tracks when useful.

# Canonical Outputs

```text
data/registry/cycle_registry.csv
data/clean/waveform_quality_scores.csv
data/clean/curated_waveforms.npz
data/clean/waveform_processing_manifest.json
code/waveform/
```

# Quality Status

- `accepted`
- `accepted_with_warning`
- `excluded`
- `needs_human_review`

Exclusion must cite measurable reasons. Do not select cycles because their targets improve model fit.

# Validation Rules

- Same file/measurement/specimen ancestry must obey R3 grouping.
- Fit alignment templates, scaling statistics, PCA/CNN representations, and anomaly thresholds only on allowed training data when learned from data.
- Never place an original cycle and augmented copy in different folds.
- Report both cycle-row count and independent specimen/formulation count.

# Model Escalation Ladder

Recommended comparison:

```text
shape statistics + Ridge/KRR
→ DTW-KNN / Catch22
→ MiniRocket/ROCKET + linear head
→ TinyCNN representation + low-capacity head
→ end-to-end deep model only after stable benefit
```

# Rules

- Do not equate equal peak timing with independence.
- Do not use target labels in quality filtering unless explicitly part of a predeclared supervised pipeline inside folds.
- Do not overwrite raw signals.
- Do not hide excluded cycles.

# Verification

- Every cycle maps to raw indices and parent lineage.
- Processing and learned transforms are split-safe.
- Quality decisions are reproducible.
- Independent sample count is not inflated by cycles or augmentation.
