# Waveform QC

Quality checks should measure signal integrity and reconstruction, not target desirability. Thresholds learned from data must be fitted inside training scope.
