---
name: physics-informed-feature-builder
description: Design and audit a materials feature manifest with measured, declared, derived, learned, and proxy features; units, formulas, assumptions, valid ranges, fold-computation rules, missingness behavior, and leakage checks.
metadata:
  version: "0.1"
---

# Purpose

Create a feature system that is reproducible, physically interpretable where appropriate, and safe under the frozen validation protocol. Do not equate a learned representation with a physical variable.

# Preconditions

- R3 split protocol is frozen.
- Data lineage and target provenance are available.
- Domain formulas or extraction procedures can be cited or explicitly labeled exploratory.

# Feature Classes

- `measured`: directly measured for the sample.
- `declared`: reported composition/process metadata.
- `derived`: deterministic calculation from declared/measured fields.
- `learned`: fitted representation, embedding, CNN feature, PCA component.
- `proxy`: indirect surrogate for a latent property.

# Workflow

1. Start from the research hypothesis and model input contract.
2. Define the smallest defensible feature set before generating broad descriptor pools.
3. For every feature record:
   - name and definition;
   - source type;
   - formula/extractor/version;
   - source fields and files;
   - unit and dimensional consistency;
   - physical meaning;
   - assumptions and valid range;
   - computation scope under the split;
   - missingness rule;
   - leakage status;
   - known redundancy or dependence.
4. Check target proxies, post-outcome measurements, duplicated labels, and variables unavailable at prediction time.
5. Check learned transforms are fitted only within permitted folds.
6. Produce a feature matrix or reproducible generator, never a hand-edited final table.
7. Compare a physically compact feature set against broader/learned representations downstream.

# Canonical Outputs

```text
data/features/feature_manifest.json
data/features/feature_matrix.csv          # when materialized
data/features/feature_generation_report.md
code/features/                            # when nontrivial generation code is required
```

Use `schemas/feature_manifest.schema.json`.

# Physical Checks

- Units must be explicit before ratios or products are interpreted.
- Dimensionless groups should document scaling and reference quantities.
- Arrhenius/WLF/kinetic features must state temperature units and mechanism assumptions.
- Mixture features must preserve component role and amount; a single concatenated SMILES is not a valid polymer formulation representation.
- Process variables are part of the material state, not optional noise.

# Learned Features

For CNN, ROCKET, embeddings, PCA, autoencoders, or pretrained representations record:

- training population;
- fold scope;
- dimension;
- normalization;
- checkpoint/version;
- whether pretrained data overlap the evaluation domain;
- whether interpretation is descriptive only.

# Rules

- Do not use target-derived feature selection outside inner folds.
- Do not fill unknown chemistry with invented descriptors.
- Do not mix units silently.
- Do not rename proxies as mechanisms.
- Do not generate hundreds of features merely because a package supports them.

# Verification

- Every active feature has a complete contract.
- No forbidden target information enters inputs.
- Computation scope matches R3.
- Learned and physical features remain distinguishable.
- Feature set ID/version is stable and referenced by model runs.
