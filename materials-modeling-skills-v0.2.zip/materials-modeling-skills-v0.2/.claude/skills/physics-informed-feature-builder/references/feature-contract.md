# Feature Contract Checklist

A feature is incomplete without source, unit, formula/extractor, version, physical meaning, assumptions, valid range, fold scope, missingness behavior, and leakage review.
