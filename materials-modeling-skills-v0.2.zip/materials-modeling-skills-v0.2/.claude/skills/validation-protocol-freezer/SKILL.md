---
name: validation-protocol-freezer
description: Define and freeze the scientific inference target, grouped outer test design, inner tuning split, blind-set role, fold-safe preprocessing, feature selection, augmentation, and representation-learning scope for materials small-sample modeling.
metadata:
  version: "0.1"
---

# Purpose

Turn the scientific generalization claim into an executable, immutable validation contract before model training.

# Preconditions

- R2 data lineage is ready.
- `sample_registry.csv` contains required group IDs.
- The user can decide what future object the model should generalize to.

# Human-Owned Choice

Ask the smallest necessary question:

> Is the intended claim about unseen cycles, measurements, specimens, batches, formulations, composition series, papers, or chemistry families?

Present consequences. Do not choose the inference target for the researcher.

# Split Mapping

Recommended minimum outer grouping:

| Inference target | Grouping |
|---|---|
| unseen cycle | measurement/specimen-aware |
| unseen specimen | specimen |
| unseen batch | batch |
| unseen formulation | formulation |
| unseen series | series |
| unseen paper | paper |
| unseen chemistry family | chemistry family |

Use stricter nested grouping when shared ancestry creates leakage.

# Workflow

1. Record the human-approved inference target.
2. Define outer evaluation strategy and immutable held-out groups.
3. Define inner model-selection split using only outer-training data.
4. Define exact scopes for:
   - cleaning rules learned from data;
   - imputation;
   - scaling;
   - feature selection;
   - peak/cycle filtering;
   - augmentation;
   - learned representation fitting;
   - hyperparameter tuning;
   - calibration/conformal fitting.
5. Assign every registry row to outer and inner roles.
6. Declare blind/external datasets and their single allowed role.
7. Define metrics before model comparison.
8. Validate no parent group crosses forbidden boundaries.
9. Write the protocol, assignments, protocol hash, and human freeze decision.

# Canonical Outputs

```text
planning/validation/split_protocol.json
planning/validation/split_assignments.csv
planning/validation/protocol_freeze.json
planning/validation/protocol_change_log.jsonl
```

Use `schemas/split_protocol.schema.json`.

# Special Cases

## Incremental training

A held-out series may be used for staged retraining only if its role is declared in advance. Once used for training or model choice, it cannot remain the final blind test.

## Time/order-independent peaks

Even when peaks are physically independent in sequence order, peaks from the same specimen/file may share acquisition and material ancestry. Split by the intended future unit, not by temporal ordering alone.

## Leave-one-paper-out

All rows from a held-out paper remain outside feature fitting, imputation, normalization, model selection, and calibration.

# Amendments

To change a frozen protocol:

1. append a reason;
2. mark prior protocol `SUPERSEDED`;
3. record whether evidence was viewed;
4. create a new protocol ID and hash;
5. invalidate downstream model and claim artifacts.

Do not silently edit a frozen protocol.

# Rules

- No model training before freeze.
- No blind-set reuse for routine tuning.
- No preprocessing outside the permitted fold scope.
- No augmented siblings across train/test.
- Do not optimize the split to improve model scores.

# Verification

- The split answers the declared inference target.
- All ancestry leakage checks pass.
- Preprocessing and augmentation are fold-safe.
- Blind-set roles are unique.
- Assignments cover every usable row.
- Protocol hash matches canonical content.
