# Split Patterns

- `GroupKFold(formulation_id)` supports unseen-formulation claims within represented chemistry.
- held-out composition series supports interpolation/extrapolation across a declared series boundary.
- leave-one-paper-out estimates transfer across study protocols.
- nested grouping may require paper outside, formulation inside.
- repeated random row splits are diagnostic only when rows are truly independent.
