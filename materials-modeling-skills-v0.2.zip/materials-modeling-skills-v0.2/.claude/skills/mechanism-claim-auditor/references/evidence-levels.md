# Evidence Ladder

Association < model dependence < mechanism consistency < mechanism support. Modeling outputs cannot skip levels without independent experimental evidence.
