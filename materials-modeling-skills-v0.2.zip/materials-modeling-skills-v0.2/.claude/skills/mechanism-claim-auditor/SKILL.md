---
name: mechanism-claim-auditor
description: Classify and audit materials-science claims as association, model dependence, mechanism consistency, or mechanism support; link each claim to experiments, models, literature, uncertainty, competing explanations, and allowed manuscript wording.
metadata:
  version: "0.1"
---

# Purpose

Prevent predictive explanations and correlations from being promoted into unsupported chemical or physical mechanisms. Build a claim-evidence matrix for paper writing and review.

# Evidence Levels

1. `association`
   - observed statistical relation;
   - no causal or mechanistic implication.

2. `model_dependence`
   - model predictions rely on a feature/representation under a defined background and model;
   - includes SHAP, feature importance, ablation, saliency.

3. `mechanism_consistent`
   - trends, kinetics, structure-property direction, or symbolic relation agree with a mechanism;
   - plausible alternatives remain.

4. `mechanism_supported`
   - controlled intervention, orthogonal characterization, kinetic discrimination, or converging evidence addresses alternatives.

# Workflow

For each proposed claim:

1. Write the exact claim and intended manuscript strength.
2. Identify evidence artifacts:
   - raw/processed experiments;
   - model validation;
   - uncertainty/external validation;
   - ablation/SHAP/PySR;
   - literature;
   - spectroscopy, kinetics, rheology, thermal, microscopy, or control experiments.
3. List competing explanations and whether they were tested.
4. Assign the maximum defensible evidence level.
5. Check the claim's population and conditions match validation scope.
6. Check numerical values against the freeze.
7. Suggest allowed wording and forbidden stronger wording.
8. Ask the researcher to keep, narrow, downgrade, or drop the claim.

# Canonical Outputs

```text
claims/claim_evidence_matrix.json
claims/mechanism_claim_audit.md
claims/claim_decisions.jsonl
```

A claim record includes:

```json
{
  "claim_id": "c1",
  "claim_text": "...",
  "evidence_level": "mechanism_consistent",
  "evidence_artifacts": [],
  "validation_scope": "unseen_formulation within one chemistry family",
  "competing_explanations": [],
  "uncertainty": "...",
  "allowed_wording": "is consistent with",
  "forbidden_wording": "proves / determines / causes",
  "human_status": "AWAITING_DECISION"
}
```

# Interpretation Rules

- SHAP describes model behavior under a masker/background choice.
- Symbolic regression discovers compact predictive relations, not automatically laws.
- Correlation across literature papers may reflect paper-level protocol differences.
- Feature ablation may support model dependence but not chemical causality.
- A monotonic trend may be consistent with several mechanisms.

# Rules

- Do not invent physical meaning absent from the decision/evidence record.
- Do not use “mechanism” for level 1 or 2 claims.
- Do not hide contradictory experiments.
- Do not broaden the claim beyond the validated material/process domain.
- Human approval is required for final wording strength.

# Verification

- Every claim has source evidence and scope.
- Evidence level follows the strongest actual evidence, not narrative ambition.
- Competing explanations and missing tests are visible.
- Numerical and figure references resolve to frozen/current artifacts.
