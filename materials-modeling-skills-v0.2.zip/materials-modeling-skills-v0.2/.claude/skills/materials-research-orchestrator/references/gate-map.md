# Gate Map

R0/R1 may be supplied by external research skills. R5/R5.5/R6 and freeze/audits may be supplied by MathModeling-skills. This orchestrator owns cross-system routing and must treat R2, R3, R7, R8, and R10 as mandatory scientific boundaries.
