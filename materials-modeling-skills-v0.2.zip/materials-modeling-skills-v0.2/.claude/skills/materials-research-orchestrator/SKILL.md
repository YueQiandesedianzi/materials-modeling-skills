---
name: materials-research-orchestrator
description: Inspect a materials-science modeling workspace, evaluate research gates R0-R11, update the canonical research manifest, classify change impact, and route one next action without performing modeling or inventing scientific judgments.
metadata:
  version: "0.1"
---

# Purpose

Act as the state reader and gate-driven scheduler for a materials modeling project. Do not choose a scientific claim, select the final method, train models, design a final experiment batch, or draft unsupported paper conclusions.

Read `AGENTS.md` as the policy source.

# Session Start

1. Inspect `planning/session_config.json`.
2. Inspect `planning/research_manifest.json` if present.
3. Locate canonical artifacts for R0-R11.
4. Check repository status and relevant runtime only when needed.
5. Report concise warnings; do not generate the whole workspace unless initialization is requested.

# State Sources

Prefer:

1. `planning/research_manifest.json`;
2. canonical artifacts on disk;
3. compatible MathModeling manifests/decision ledgers;
4. legacy notes only when canonical artifacts are absent.

Never trust a prose progress note over newer artifacts.

# Manifest Contract

Maintain:

```json
{
  "schema_version": 1,
  "project_id": "materials-project",
  "domain_profile": "waveform_teng",
  "current_gate": "R3",
  "status": "protocol_waiting_human_freeze",
  "inference_target": "unseen_formulation",
  "artifacts": {
    "sample_registry": "data/registry/sample_registry.csv",
    "split_protocol": "planning/validation/split_protocol.json"
  },
  "allowed": {
    "feature_building": false,
    "model_training": false,
    "external_claims": false,
    "next_batch_design": false,
    "paper_claim_freeze": false
  },
  "blockers": [],
  "next_action": {
    "owner": "human",
    "skill": "validation-protocol-freezer",
    "reason": "outer generalization target is not frozen"
  },
  "updated_at": "ISO-8601"
}
```

Update only fields affected by the current change.

# Gate Evaluation

Evaluate R0-R11 according to `AGENTS.md`.

Important routing rules:

- no lineage → `materials-data-lineage-auditor`;
- no inference target/split freeze → `validation-protocol-freezer`;
- no feature contract → `physics-informed-feature-builder` plus domain add-on if applicable;
- method not screened → external `method-selector`;
- method not human-chosen → external choice card/decision logger;
- code not reviewed → external generator/reviewer;
- no grouped benchmark → `small-sample-model-benchmarker`;
- no external/uncertainty judgment → `uncertainty-external-validation-auditor`;
- next experiment requested → `active-learning-doe-planner` only after R8;
- paper mechanism/claim work → `mechanism-claim-auditor` only after validated evidence exists.

# Change Impact

Classify each material change as `NONE`, `LOCAL`, `DATA`, `PROTOCOL`, `FEATURE`, `MODEL`, or `CLAIM` using `AGENTS.md`. Mark only affected downstream artifacts stale.

Never rerun the entire project because several formatting files changed. Never preserve a model claim after its governing protocol changed.

# Output

Return:

- active profile;
- current gate and status;
- canonical artifacts present/missing;
- blockers;
- allowed actions;
- change-impact class;
- one primary next action;
- independent runner-up only when it cannot conflict with the main action.

# Verification

- State is artifact-derived.
- R2/R3 block model training.
- Human judgments were not inferred.
- Reported inference target matches the split protocol.
- Staleness propagation matches semantic impact.
- Manifest and returned next action agree.
