# Baseline Ladder Guidance

Start with the lowest-capacity model that can complete the real task. A complex method earns promotion only through stable grouped-validation improvement, not through appearance or one split.
