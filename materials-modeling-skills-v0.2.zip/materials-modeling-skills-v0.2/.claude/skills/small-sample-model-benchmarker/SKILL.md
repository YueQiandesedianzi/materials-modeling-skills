---
name: small-sample-model-benchmarker
description: Benchmark materials models under a frozen grouped validation protocol using a low-to-high complexity baseline ladder, nested model selection, fold-level predictions, uncertainty intervals, negative controls, subgroup analysis, and complexity-aware verdicts.
metadata:
  version: "0.1"
---

# Purpose

Determine whether a model provides stable scientific value beyond credible lower-capacity baselines under the intended generalization target. Do not select the final model or hide unfavorable folds.

# Preconditions

- R3 protocol is `FROZEN`.
- R4 feature manifest is current.
- Approved candidate roles exist or a benchmark plan is requested before method screening.

# Baseline Ladder

Use only applicable levels:

- `B0`: target prior, mean, median, class prior, simple physical reference.
- `B1`: linear/logistic, Ridge, PLS.
- `B2`: KRR, GPR, SVR/SVC, DTW-KNN.
- `B3`: GBR, RF, carefully constrained boosting.
- `B4`: physics-informed features plus low-capacity model.
- `B5`: learned representation or deep model.

A method that cannot complete the real task is a diagnostic reference, not an official baseline.

# Workflow

1. Read frozen assignments; do not regenerate convenient splits.
2. Predeclare models, metrics, tuning spaces, compute budget, and primary comparison.
3. Run nested grouped validation or the protocol-specified equivalent.
4. Save out-of-fold predictions for every row and fold.
5. For each model report:
   - fold metrics and distribution;
   - aggregate metric with uncertainty interval;
   - train/validation gap;
   - subgroup/held-group performance;
   - prediction variance and concentration;
   - calibration where relevant;
   - runtime and parameter count/complexity proxy.
6. Run negative controls where feasible:
   - target permutation within valid grouping;
   - shuffled/irrelevant feature;
   - label-prior baseline;
   - duplicate-leakage sentinel.
7. Evaluate whether apparent uplift exceeds fold uncertainty and protocol sensitivity.
8. Produce an evidence card for the human: proceed, simplify, adjust features/protocol, or activate fallback.

# Canonical Outputs

```text
results/validation/benchmark_plan.json
results/validation/fold_predictions.csv
results/validation/fold_metrics.csv
results/validation/benchmark_summary.json
results/validation/benchmark_report.md
```

Use `schemas/validation_report.schema.json`.

# Required Diagnostics

- effective independent sample count, not only row count;
- number and identity of outer groups;
- worst-group performance;
- metric concentration/instability;
- learning curve or data-ablation when feasible;
- repeated-seed stability only inside a fixed split design;
- model ranking stability;
- whether the complex model's advantage survives excluding one influential group.

# Deep Model Gate

A deep model is eligible as main only when:

- it respects group splits and augmentation boundaries;
- it beats credible B1/B2/B4 baselines by a practically meaningful margin;
- improvement is not driven by one group;
- representation dimensionality and training stability are documented;
- external validation remains planned.

# Rules

- Do not report only the best seed or fold.
- Do not tune on external/blind groups.
- Do not compare models using different rows, units, metrics, or preprocessing.
- Do not interpret SHAP or feature importance before predictive validation.
- Do not declare success from R² alone.

# Verification

- Every prediction traces to protocol, fold, feature set, and model version.
- Main/baseline comparison is directly compatible.
- Negative controls and worst-group evidence are visible.
- Verdict follows stability and practical uplift, not leaderboard appearance.
