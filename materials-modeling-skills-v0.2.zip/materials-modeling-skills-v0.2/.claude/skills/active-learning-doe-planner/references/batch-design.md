# Batch Design Roles

A robust small batch usually combines exploitation, uncertainty exploration, diversity, mechanism discrimination, and repeat/control anchors. The exact ratio depends on model validity and experimental risk.
