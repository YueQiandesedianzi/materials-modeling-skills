---
name: active-learning-doe-planner
description: Propose a constrained, information-rich next batch of materials experiments using validated surrogate models, calibrated uncertainty, chemistry/process feasibility, controls, repeat structure, budget, and human scientific priorities.
metadata:
  version: "0.1"
---

# Purpose

Design the next experiment batch as a scientific decision, not merely an optimizer output. Balance exploitation, exploration, mechanism discrimination, boundary checks, and reproducibility controls.

# Preconditions

- R8 validation status is known.
- Surrogate scope and failure regions are explicit.
- Candidate space and hard constraints are available.
- Experimental resources, synthesis capacity, testing budget, and batch size are known.

If the surrogate fails the relevant target-space validation, use DOE or mechanism-driven sampling instead of model-guided optimization.

# Candidate Contract

Every proposed candidate records:

- formulation/process variables and units;
- feasibility checks;
- predicted objectives;
- uncertainty;
- distance to training domain;
- acquisition rationale;
- role: exploitation, uncertainty exploration, diversity, mechanism discrimination, boundary check, replicate anchor, or control;
- expected information gain or decision consequence;
- synthesis/test risks;
- fallback if synthesis fails.

# Workflow

1. Freeze the feasible candidate space and constraint set.
2. Audit hard constraints before scoring:
   - composition sum and stoichiometry;
   - equivalent ratio/functionality;
   - ingredient availability;
   - viscosity/gelation/process window;
   - temperature/time/equipment bounds;
   - safety and measurement limits.
3. Choose acquisition logic appropriate to model validity:
   - uncertainty sampling;
   - expected improvement;
   - constrained multi-objective EHVI/qEHVI;
   - diversity-aware batch selection;
   - mechanism discrimination;
   - space-filling DOE when uncertainty is untrustworthy.
4. Construct a balanced batch, typically including:
   - 1–2 exploitation points;
   - 1–2 uncertainty/diversity points;
   - 1 mechanism/boundary point;
   - 1 repeat anchor or control.
5. Check batch-level diversity and shared synthesis dependencies.
6. Produce candidate audit and a compact human choice card.
7. Only after human approval write the final experiment card.

# Canonical Outputs

```text
experiments/next_batch/candidate_space.json
experiments/next_batch/candidate_audit.csv
experiments/next_batch/next_batch.json
experiments/next_batch/experiment_card.md
experiments/next_batch/decision.json
```

Use `schemas/next_batch.schema.json`.

# Rules

- Do not optimize outside the validated domain without labeling boundary exploration.
- Do not treat model optimum as experimentally feasible.
- Do not return only high-performing near-duplicate candidates.
- Do not omit controls or repeat anchors when batch drift is plausible.
- Do not approve the batch on behalf of the researcher.

# Verification

- Every candidate is feasible or explicitly exploratory.
- Batch roles are balanced and nonredundant.
- Predictions and uncertainty trace to a validated model version.
- Experimental costs and failure modes are explicit.
- Human approval is recorded before execution.
