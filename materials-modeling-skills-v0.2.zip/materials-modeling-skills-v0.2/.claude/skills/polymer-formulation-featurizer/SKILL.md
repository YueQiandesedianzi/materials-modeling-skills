---
name: polymer-formulation-featurizer
description: Build reproducible polymer-formulation features from component roles, molecular descriptors, amounts, stoichiometry, functionality, molecular weight, dynamic-bond content, hard/soft segment structure, and processing conditions without collapsing a multicomponent material into one fake molecule.
metadata:
  version: "0.1"
---

# Purpose

Represent a polymer formulation as a structured mixture plus process history. RDKit or molecular embeddings may describe individual components, but the final sample representation must preserve role, amount, stoichiometry, and processing.

# Preconditions

- Component identity and role are available or explicitly missing.
- Amount basis is known: mass, mole, equivalent, phr, or volume.
- R3 protocol is frozen before learned descriptor selection.

# Component Roles

Typical roles:

- polyol/soft segment;
- diisocyanate/hard segment precursor;
- chain extender;
- crosslinker;
- dynamic-bond monomer;
- catalyst;
- solvent;
- filler/additive;
- substrate/interface.

# Feature Families

1. **Stoichiometric**
   - NCO/OH or functional-group equivalent ratio;
   - functionality-weighted branching potential;
   - chain-extender/crosslinker fraction;
   - dynamic-bond equivalent density.

2. **Segment/structure**
   - soft/hard segment fraction;
   - component molecular weight and dispersity where known;
   - aromatic/aliphatic fraction;
   - flexible-bond, ring, polarity, H-bonding descriptors.

3. **Mixture aggregation**
   - amount-weighted mean;
   - min/max/range;
   - pairwise contrast;
   - role-specific descriptors;
   - interaction terms only when scientifically motivated.

4. **Process**
   - route, order of addition, solvent, solids content;
   - temperature/time profile;
   - catalyst;
   - drying/post-cure;
   - humidity and storage where relevant.

5. **Measurement context**
   - test temperature, rate, geometry, substrate, specimen thickness;
   - keep these separate from intrinsic composition features.

# Workflow

1. Standardize component names and structures; preserve raw text.
2. Validate SMILES/structures; do not invent missing structures.
3. Compute component descriptors with versioned RDKit/datamol/molfeat tools when justified.
4. Aggregate by role and amount basis.
5. Add stoichiometric and physically derived features.
6. Record missingness and unknown chemistry explicitly.
7. Write all features into the common feature manifest with source type and fold scope.
8. Compare compact chemistry features against broad fingerprints/embeddings downstream.

# Canonical Outputs

```text
data/features/formulation_component_registry.csv
data/features/formulation_feature_spec.json
data/features/formulation_feature_matrix.csv
code/features/formulation_featurizer.py
```

# Rules

- Do not concatenate component SMILES into a fictitious molecule.
- Do not mix mole-, mass-, and equivalent-based fractions silently.
- Do not treat catalyst or process variables as molecular descriptors.
- Do not replace unknown structures with zero vectors without a missingness indicator and rationale.
- Do not use pretrained embeddings as mechanism evidence.

# Verification

- Formula totals and equivalent ratios are reproducible.
- Component role, amount basis, descriptor version, and aggregation are traceable.
- Process and measurement context remain explicit.
- Generated features link into `feature_manifest.json`.
