# Polymer Formulation Representation

Represent each component by role-specific descriptors, amount, functionality, molecular weight, and relevant chemistry. Add stoichiometry and process history. Preserve unknowns; do not create a fake single molecule.
