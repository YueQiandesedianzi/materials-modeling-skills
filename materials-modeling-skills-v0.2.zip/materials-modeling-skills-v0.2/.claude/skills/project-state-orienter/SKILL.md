---
name: project-state-orienter
description: Quickly orient a materials or small-sample scientific modeling project by reading canonical manifests, gate artifacts, stale outputs, blocked actions, and one safe next action without rerunning analysis or inventing scientific decisions.
---

# Purpose

Provide a compact project-state briefing for a new session or handoff. Treat canonical artifacts as the source of truth. Do not train models, change protocols, approve experiments, or strengthen claims.

# Preconditions

- A project workspace may contain `planning/research_manifest.json`.
- Some canonical artifacts may be missing; report absence rather than reconstructing hidden state from conversation.

# Workflow

1. Read `planning/session_config.json` if present.
2. Read `planning/research_manifest.json` if present.
3. Check for canonical artifacts:
   - `data/registry/sample_registry.*`
   - `planning/validation/split_protocol.*`
   - `planning/validation/split_assignments.*`
   - `data/features/feature_manifest.*`
   - `results/validation/benchmark_summary.*`
   - `results/external_validation/external_validation_summary.*`
   - `experiments/next_batch/next_batch.*`
   - `claims/claim_evidence_matrix.*`
4. Compare artifact presence with `current_gate`, `allowed`, `blockers`, and `next_action`.
5. Mark stale or suspicious state when:
   - model outputs exist before R2/R3 readiness;
   - split assignments exist without a frozen protocol;
   - feature or model outputs do not name a protocol or feature-set version;
   - external validation exists but no blind/external role is declared;
   - claims exist without evidence level or validation scope.
6. Return one primary next action and at most one nonconflicting secondary action.

# Output

Return:

- active mode: `lean` or `submission`;
- domain profile;
- current gate and status;
- present canonical artifacts;
- missing or stale canonical artifacts;
- blocked actions;
- allowed actions;
- one safe next action;
- short warning if the project state is internally inconsistent.

# Rules

- Do not infer human decisions from old prose.
- Do not treat a dashboard, README, or chat note as newer than canonical artifacts.
- Do not approve model training unless R2 lineage and R3 validation protocol are ready.
- Do not produce a full audit unless explicitly requested.

# Verification

- Briefing is artifact-derived.
- Blocked and allowed actions match the manifest.
- Next action does not conflict with current gates.
