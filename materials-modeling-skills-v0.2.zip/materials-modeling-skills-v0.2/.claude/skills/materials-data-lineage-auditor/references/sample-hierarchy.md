# Sample Hierarchy Examples

- TENG: formulation → batch → specimen/device → acquisition file → cycle/peak.
- Tensile/self-healing: formulation → synthesis batch → film → specimen strip → test.
- Literature dataset: paper → formulation → condition → reported measurement; paper-level bias remains.
- Particleboard: adhesive batch → board → cut specimen → test; specimens from one board are nested.
