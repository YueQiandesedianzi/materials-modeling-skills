---
name: materials-data-lineage-auditor
description: Build and audit a materials-science sample registry that distinguishes sources, formulations, batches, specimens, measurements, cycles, technical repeats, derived rows, and augmented rows before any model split or training.
metadata:
  version: "0.1"
---

# Purpose

Define what each row represents and what counts as an independent sample. Detect pseudoreplication, duplicate evidence, batch mixing, unit conflicts, target provenance problems, and leakage paths. Preserve raw data.

# Preconditions

- Raw files are under `data/raw/` or a documented read-only path.
- The research question and target outputs are known enough to identify candidate sample units.
- Stop rather than invent identities, units, batch relationships, or paper-to-sample mappings.

# Canonical Hierarchy

```text
source_or_paper
→ chemistry_family
→ series
→ formulation
→ synthesis_batch
→ specimen
→ measurement
→ cycle_or_peak
```

Not all levels are mandatory. Any omitted level must be explicit.

# Workflow

1. Inventory raw files, sheets, headers, units, timestamps, and source metadata.
2. Assign stable IDs for all applicable hierarchy levels.
3. Classify each row as `independent`, `technical`, `derived`, `augmented`, or `unknown`.
4. Identify the narrowest defensible independence unit for each target.
5. Detect:
   - exact and near duplicates;
   - the same specimen measured repeatedly;
   - multiple cycles/peaks from one waveform;
   - several rows copied from the same paper table;
   - multiple formulations from one shared synthesis batch;
   - target values duplicated across derived or augmented rows;
   - units or target definitions that change across sources;
   - group IDs missing from training-ready rows.
6. Record exclusions and corrections with source locators and reasons.
7. Produce readiness per target and proposed grouping candidates, but do not freeze the validation protocol.

# Canonical Outputs

```text
data/registry/sample_registry.csv
data/registry/lineage_graph.json
data/registry/data_quality_report.md
data/registry/lineage_change_log.jsonl   # only when material changes occur
```

Required registry fields include:

- `row_id`
- `source_id`, optional `paper_id`
- `chemistry_family_id`, `series_id`
- `formulation_id`
- `batch_id`
- `specimen_id`
- `measurement_id`
- optional `cycle_id`
- `replicate_type`
- `independence_unit`
- target name/value/unit
- raw file and locator
- quality status and exclusion reason

Use `schemas/sample_registry.schema.json` as the semantic reference.

# Domain Rules

## Waveforms

- Peaks from the same continuous recording are nested observations.
- Augmented copies inherit all parent group IDs.
- Peak acceptance criteria must not use held-out target labels.

## Literature datasets

- Rows from the same paper share source-level bias.
- A formulation reported at several conditions may be repeated-measures data, not independent formulations.
- Digitized values, author-reported values, and recalculated values require distinct provenance.

## Polymer experiments

- Same nominal formulation synthesized in different batches is not the same as technical repeats.
- Multiple specimens cut from one film/board may share batch-level dependence.

# Rules

- Never overwrite raw data.
- Never collapse repeats without preserving row-level provenance.
- Never call cycle count, repeated tests, or augmented rows “sample size” without qualification.
- Do not choose the final split.
- Do not silently resolve identity conflicts.

# Verification

- Every modeling row has sufficient group IDs.
- Independence is distinguished from repetition.
- Target and unit provenance are traceable.
- Exclusions are reproducible.
- R2 readiness and unresolved blockers are explicit.
