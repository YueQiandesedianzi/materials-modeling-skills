---
name: model-execution-contract-builder
description: Convert a frozen sample registry, split protocol, and feature manifest into a machine-readable model execution contract that package skills and training code must obey, including task type, targets, group keys, allowed models, forbidden leakage patterns, metrics, and output requirements.
---

# Purpose

Bridge research governance and algorithm execution. Produce a contract that scikit-learn, PyMC, Aeon, PySR, SHAP, PyMOO, or PyTorch workflows must follow. Do not select the final model or run training unless the user separately asks.

# Preconditions

- R2 data lineage is ready.
- R3 validation protocol is frozen.
- R4 feature manifest exists or the contract explicitly blocks modeling.

# Workflow

1. Read:
   - `data/registry/sample_registry.*`
   - `planning/validation/split_protocol.*`
   - `planning/validation/split_assignments.*`
   - `data/features/feature_manifest.*`
2. Identify the modeling task:
   - regression, classification, ranking, time-series regression/classification, Bayesian hierarchical model, or multi-objective surrogate.
3. Record:
   - target columns and units;
   - feature set ID and feature matrix path or generator;
   - row ID key;
   - outer and inner split assignment columns;
   - group keys that must not cross folds;
   - blind/external rows and their allowed role;
   - metrics and optimization direction;
   - random seed policy.
4. Declare allowed model families and required package skills.
5. Declare forbidden operations:
   - random row split when grouped split is required;
   - global scaling, imputation, feature selection, augmentation, or representation fitting before CV;
   - blind-set tuning;
   - target-derived filtering outside inner folds;
   - original and augmented siblings in different folds;
   - metric reporting without fold-level predictions.
6. Define output contract for every model run.

# Canonical Output

```text
planning/model_execution_contract.json
```

Use `schemas/model_execution_contract.schema.json`.

# Minimal Contract Shape

```json
{
  "contract_id": "model-contract-v1",
  "protocol_id": "split-protocol-v1",
  "feature_set_id": "phys-v1",
  "task_type": "regression",
  "targets": [{"name": "target", "unit": "unknown"}],
  "row_id": "row_id",
  "split_assignments": "planning/validation/split_assignments.csv",
  "outer_role_column": "outer_role",
  "inner_role_column": "inner_fold",
  "group_keys": ["formulation_id"],
  "allowed_model_families": ["ridge", "gpr", "svr"],
  "forbidden_operations": ["random_train_test_split", "global_preprocessing_before_cv"],
  "required_outputs": ["run_summary.json", "fold_predictions.csv", "fold_metrics.csv"],
  "status": "READY"
}
```

# Rules

- Do not weaken the frozen protocol to make package examples work.
- Do not silently choose a target or group key.
- Do not allow a package skill to create a new split unless the frozen protocol explicitly permits it.
- Do not allow SHAP, PySR, or deep embeddings before predictive validation status is clear.

# Verification

- Contract references existing canonical artifacts.
- Contract group keys match the frozen protocol.
- Forbidden operations cover known leakage paths.
- Package skills can execute from the contract without reinterpreting scientific scope.
