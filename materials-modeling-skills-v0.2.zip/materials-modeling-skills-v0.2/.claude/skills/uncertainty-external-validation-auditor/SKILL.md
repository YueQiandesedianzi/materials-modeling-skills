---
name: uncertainty-external-validation-auditor
description: Audit materials-model uncertainty, calibration, out-of-domain behavior, held-out batches/formulations/series/papers, subgroup failures, and the exact generalization claim supported by external evidence.
metadata:
  version: "0.1"
---

# Purpose

Separate interpolation performance from broader generalization. Evaluate whether uncertainty is informative and whether the model's scientific claim should be kept, narrowed, or rejected.

# Preconditions

- R7 internal benchmark exists.
- External or frozen outer-test predictions exist, or the absence is explicit.
- The external set's role was declared before use.

# Validation Levels

Track separately:

1. `interpolation_supported`
2. `group_generalization_supported`
3. `external_validation_supported`
4. `chemistry_transfer_supported`
5. `exploratory_only`

Passing one level does not imply the next.

# Workflow

1. Verify external rows were untouched during feature fitting, tuning, calibration, and model choice.
2. Evaluate point performance using predeclared metrics.
3. Evaluate uncertainty:
   - empirical coverage;
   - interval width;
   - coverage by subgroup and distance-to-domain;
   - sharpness/calibration trade-off;
   - uncertainty-error correlation;
   - failure to flag large errors.
4. Quantify domain shift:
   - feature range/extrapolation;
   - similarity or distance to training groups;
   - chemistry/process novelty;
   - batch/source differences.
5. Compare external performance with internal estimates and baselines.
6. Identify influential groups, failure regimes, and unsupported populations.
7. Produce a claim-scope choice card for the human: keep, narrow, downgrade to exploratory, or drop.

# Canonical Outputs

```text
results/external_validation/external_predictions.csv
results/external_validation/uncertainty_calibration.csv
results/external_validation/external_validation_summary.json
results/external_validation/external_validation_report.md
results/external_validation/claim_scope_options.json
```

# Accepted Uncertainty Sources

- GPR/posterior predictive intervals;
- hierarchical Bayesian posterior;
- bootstrap or deep ensemble;
- conformal prediction fitted without external leakage;
- measurement uncertainty propagated through the model.

State whether uncertainty is epistemic, aleatoric, total, or only a heuristic disagreement score.

# Rules

- Do not call a reused tuning set external validation.
- Do not average away catastrophic subgroup failures.
- Do not present narrow but under-covering intervals as confidence.
- Do not infer chemistry transfer from formulation interpolation.
- Do not let the AI make the final claim-scope decision.

# Verification

- External role and chronology are valid.
- Calibration is assessed, not assumed.
- OOD and subgroup failures are explicit.
- Claim level matches actual evidence.
- Limitations and unsupported regions are machine-readable and visible.
