# Validation Levels

Interpolation, group generalization, external validation, and chemistry transfer are different scientific claims. Report each independently.
