# Core Philosophy

- **AI owns mechanical correctness; the researcher owns scientific judgment.**
- Independent-sample definition, inference target, blind-test role, experimental feasibility, mechanism interpretation, and publication claim scope are human-owned.
- Start from research question, mechanism hypothesis, unit of inference, data-generating process, constraints, evidence, and falsifiable conclusion — not from model names.
- Preserve raw data. Never silently redefine rows, groups, replicates, batches, formulations, or targets.
- A high score under the wrong split is a failed experiment, not a successful model.
- Model explanation is not mechanism evidence. SHAP, feature importance, embeddings, and symbolic formulas require independent scientific support.

# Configuration

`planning/session_config.json`:

```json
{
  "interaction_mode": "learning",
  "rigor_profile": "lean",
  "mode": "lean",
  "domain_profile": "polymer_materials",
  "primary_inference_target": "unseen_formulation",
  "implementation_target": "python"
}
```

- `interaction_mode`: `learning` or `speed`.
- `rigor_profile`: `lean` or `submission`.
- `mode`: `lean` for daily exploration or `submission` for paper-grade audit.
- `domain_profile`: e.g. `polymer_materials`, `waveform_teng`, `literature_meta_dataset`, `adhesive_doe`.
- `primary_inference_target` is provisional until R3 is frozen.
- Default to `learning + lean`.

## Mode Contract

`lean` mode must still protect the three hard scientific boundaries:

1. R2 data lineage before any split-dependent feature or model claim.
2. R3 frozen validation protocol before model training.
3. R7 small-sample benchmark before interpreting model superiority.

`submission` mode requires the full R0-R11 chain, including research design, external validation, claim evidence, frozen numbers, and final audits.

Use `project-state-orienter` at the start of a new session when the user asks for status, continuation, or "where are we now".

# Canonical State

Use `planning/research_manifest.json` as the primary machine-readable state source. Use canonical artifacts on disk as evidence. Do not infer completion from conversation history or a dashboard.

A minimal manifest:

```json
{
  "schema_version": 1,
  "project_id": "project-name",
  "mode": "lean",
  "current_gate": "R2",
  "status": "lineage_in_progress",
  "inference_target": null,
  "artifacts": {},
  "allowed": {
    "feature_building": false,
    "model_training": false,
    "external_claims": false,
    "next_batch_design": false,
    "paper_claim_freeze": false
  },
  "blockers": [],
  "next_action": {}
}
```

# Gate Contract

## R0 — TOPIC_WORTH_PURSUING

Pass when the gap is plausibly open, the contribution is distinguishable from a permutation of existing work, and the project is feasible under available time, data, synthesis, testing, and compute constraints.

Recommended producer: external `gap-to-topic`.

## R1 — RESEARCH_DESIGN_LOCKED

Pass when research question, target population/material space, mechanism hypothesis, competing explanations, intervention/observation design, identifiability limits, validation plan, and stopping criteria exist.

Recommended producer: external `research-design-helper`.

## R2 — DATA_LINEAGE_READY

Pass when:

- every row maps to a source, formulation, batch, specimen, measurement, and repeat/cycle level as applicable;
- technical repeats and biological/materially independent repeats are distinguished;
- pseudoreplication and leakage paths are named;
- raw data remain read-only;
- unresolved identity or unit conflicts are either corrected with provenance or blocking.

Producer: `materials-data-lineage-auditor`.

## R3 — VALIDATION_PROTOCOL_FROZEN

Pass when:

- the inference target is explicit;
- outer test grouping matches that target;
- inner tuning split is defined;
- preprocessing, feature selection, augmentation, imputation, and normalization scopes are fold-safe;
- blind/external sets have one declared role and are not reused for routine tuning;
- split assignments and protocol hash are frozen.

Producer: `validation-protocol-freezer`.

No model training is allowed before R2 and R3 pass.

## R4 — FEATURE_SCHEMA_READY

Pass when each feature has source type, formula or extraction method, unit, assumptions, valid range, fold-safety rule, missing-data rule, and leakage status. Learned representations must be separated from measured/derived physical variables.

Producer: `physics-informed-feature-builder`, optionally `polymer-formulation-featurizer` or `waveform-cycle-curator`.

## R4.5 — MODEL_EXECUTION_CONTRACT_READY

Pass when a machine-readable model execution contract links the frozen protocol, split assignments, feature set, target, row IDs, group keys, allowed model families, forbidden leakage operations, and required outputs.

Producer: `model-execution-contract-builder`.

Package skills and training code may use scikit-learn, PyMC, Aeon, SHAP, PyMOO, PySR, RDKit, PyTorch, or other tools only inside this contract. Package examples never override the frozen split or preprocessing scope.

## R5 — METHOD_SCREENED

Use the external MathModeling method-screening contract:

- one main candidate;
- one genuinely usable baseline;
- at most one conditional fallback;
- risk probes for executability, data coverage, assumption failure, output degeneracy, perturbation sensitivity, scale, and domain-specific leakage.

## R5.5 — METHOD_CHOSEN_BY_HUMAN

A human decision must cite the method card and risk probe. The AI must not originate or strengthen the rationale.

## R6 — CODE_AND_RUN_REVIEWED

Pass when approved main and baseline run under the frozen protocol; fold assignments, preprocessing scope, feature version, seed, environment, predictions, metrics, warnings, and output paths are recorded; code review verifies syntax, input contract, method alignment, reproducibility, split integrity, and output contract.

## R7 — INTERNAL_VALIDATION_PASSED

Pass when the model is compared against the fixed baseline ladder using nested or otherwise justified grouped validation, with fold-level predictions, uncertainty intervals, negative controls, subgroup results, performance concentration, and stability. One favorable split is insufficient.

Producer: `small-sample-model-benchmarker`.

## R8 — EXTERNAL_VALIDATION_JUDGED

Pass when external/held-out performance, uncertainty calibration, out-of-domain behavior, subgroup failures, and claim scope are judged. A model may pass interpolation while failing unseen-formulation or leave-one-paper-out generalization; these must remain separate statuses.

Producer: `uncertainty-external-validation-auditor`.

## R9 — NEXT_EXPERIMENT_APPROVED

Pass when proposed experiments satisfy chemistry/process constraints, model-validity requirements, uncertainty rules, information-value rationale, budget, controls, repeat structure, and human approval.

Producer: `active-learning-doe-planner`.

## R10 — CLAIMS_FROZEN

Pass when each paper claim has evidence level, source artifacts, external-validation scope, uncertainty, competing explanation, limitation, and human-approved wording strength. Numerical values must be frozen through the external freeze contract.

Producer: `mechanism-claim-auditor` plus external solution package/freeze tools.

## R11 — FINAL_AUDIT_PASSED

Require cross-file consistency, semantic completeness, and final QA. Final assembly is blocked by any failed auditor.

# Canonical Artifacts

Exploration/lean core:

```text
planning/research_manifest.json
planning/decisions.jsonl
data/registry/sample_registry.csv
data/registry/lineage_graph.json
planning/validation/split_protocol.json
planning/validation/split_assignments.csv
data/features/feature_manifest.json
planning/model_execution_contract.json
results/validation/benchmark_summary.json
results/external_validation/external_validation_summary.json
```

Submission additions:

```text
results/frozen/frozen_numbers.json
claims/claim_evidence_matrix.json
claims/mechanism_claim_audit.md
paper/audits/
```

# Data Lineage Rules

- Preserve `data/raw/` as read-only.
- The canonical hierarchy is:

```text
source_or_paper
→ formulation
→ synthesis_batch
→ specimen
→ measurement
→ cycle_or_peak
```

- Not every project uses every level, but omitted levels require a reason.
- Multiple cycles from one waveform, repeated tensile pulls from one specimen, repeated rows from one paper, and augmented copies are not automatically independent samples.
- Every training row must carry group identifiers sufficient to enforce the frozen protocol.

# Validation Rules

- Split by the future object of generalization, not by convenient rows.
- Fit all learned preprocessing inside inner training folds.
- Target-derived filtering, peak selection, feature selection, imputation, normalization, augmentation, and representation learning are part of the model pipeline and must obey the split.
- A blind set used for model selection is no longer blind.
- Any change to inference target, group key, outer holdout, or blind-set role is a `PROTOCOL` change and invalidates downstream benchmark claims.

# Model Execution Rules

- Build `planning/model_execution_contract.json` before running package-specific modeling workflows.
- Training scripts must consume the frozen split assignments rather than regenerate random row splits.
- Learned preprocessing, imputation, feature selection, augmentation, representation learning, tuning, and calibration must follow the contract scope.
- SHAP, PySR, saliency, or representation interpretation is blocked until the predictive model has a compatible validation record.
- Optimization tools such as PyMOO operate on validated surrogate scope only; outside-domain suggestions must be labeled exploratory.

# Small-Sample Benchmark Rules

Use the smallest credible complexity ladder:

```text
B0  target prior / mean / median / class prior
B1  linear, Ridge, PLS, logistic
B2  KRR, GPR, SVR/SVC
B3  GBR, RF, XGB-like tree ensemble
B4  physics-informed features + low-capacity model
B5  learned representation or deep model
```

- Do not require every level. Stop when a simpler model answers the research question.
- Deep models must demonstrate stable benefit over lower-capacity baselines under the same grouped protocol.
- Report fold predictions and uncertainty, not only mean metrics.
- Use target permutation or another negative control when feasible.

# Feature Rules

Feature source types:

- `measured`
- `declared`
- `derived`
- `learned`
- `proxy`

Each feature must record:

- definition/formula;
- unit;
- source columns/files;
- physical meaning;
- assumptions;
- valid range;
- fold computation rule;
- missingness rule;
- leakage risk;
- applicability to specific model families.

# Claim Evidence Levels

1. `association` — statistical association only.
2. `model_dependence` — the fitted model relies on the variable/representation.
3. `mechanism_consistent` — result is consistent with a mechanism but alternatives remain.
4. `mechanism_supported` — controlled intervention, kinetics, characterization, or converging evidence supports the mechanism.

SHAP, feature importance, symbolic regression, and latent embeddings cannot by themselves exceed level 2; with independent theory and trend evidence they may support level 3.

# Change Impact

Classify before rerunning work:

- `NONE`: formatting, comments, scratch.
- `LOCAL`: exploratory code or noncanonical visualization.
- `DATA`: raw/clean values, sample identities, units, target corrections.
- `PROTOCOL`: inference target, group key, split, blind-set role, augmentation scope.
- `FEATURE`: formula, source, unit, featurizer, representation version.
- `MODEL`: approved method, hyperparameters, training code, environment.
- `CLAIM`: frozen number, figure, interpretation, claim wording or scope.

Propagation:

- `DATA` → revisit R2, then R3–R10 as affected.
- `PROTOCOL` → invalidate R5–R10.
- `FEATURE` → invalidate model runs and downstream claims using it.
- `MODEL` → rerun R6–R10.
- `CLAIM` → re-freeze and scoped audit.

# Human Decisions

Append to `planning/decisions.jsonl` or the compatible MathModeling per-question ledger. Required human-owned decisions include:

- inference target;
- blind-set role;
- method choice;
- final result verdict;
- external generalization claim;
- next experiment batch;
- mechanism evidence level;
- publication claim scope.

Never convert an AI suggestion into a human rationale.

# Integration Boundaries

- Research-gap and research-design skills may produce R0/R1 artifacts.
- MathModeling skills may own method screening, code generation/review, result freeze, and final auditors.
- Package skills may implement scikit-learn, PyMC, Aeon, SHAP, PyMOO, RDKit, PySR, or PyTorch operations.
- This repository's frozen lineage, split protocol, feature manifest, validation status, and claim rules override generic package examples.

# Verification

Before reporting progress:

- derive state from canonical artifacts;
- do not confuse cycles/measurements with independent specimens;
- ensure no training occurred before protocol freeze;
- ensure the reported metric matches the declared inference target;
- ensure explanations are not presented as mechanism proof;
- return one primary next action.
