# Workflow Notes

## How this extends MathModeling-skills

MathModeling-skills remains the preferred source for:

- role-based method shortlist;
- human method choice;
- code plan and language review;
- result package and frozen numbers;
- consistency/completeness/QA auditors.

Materials Modeling Skills inserts mandatory research gates before and after that core:

```text
Data lineage → Validation protocol → Feature contract
→ Model execution contract → MathModeling method/code gates
→ Small-sample benchmark → External validation
→ Active learning/DOE → Mechanism claim audit
```

## Lean vs submission

Use `lean` mode for daily research iteration. It keeps three hard gates: lineage, frozen validation protocol, and grouped benchmark.

Use `submission` mode when preparing a paper, release, or external delivery. It requires the full R0-R11 workflow, claim evidence, frozen numbers, and final audits.

## Inference target examples

| Scientific claim | Minimum correct outer grouping |
|---|---|
| Generalizes to another cycle of the same specimen | measurement/specimen-aware split |
| Generalizes to a newly fabricated specimen | specimen split |
| Generalizes across synthesis batches | batch split |
| Predicts a new formulation | formulation split |
| Predicts a held-out composition series | series split |
| Transfers across published studies | leave-one-paper-out |
| Transfers across polymer chemistry families | chemistry-family split |

A stricter split may answer a broader claim. A weaker split cannot support a broader claim.

## Typical TENG sequence

```text
waveform-cycle-curator
→ materials-data-lineage-auditor
→ validation-protocol-freezer (formulation/series holdout)
→ physics-informed-feature-builder
→ model-execution-contract-builder
→ method-selector (statistical baseline, Aeon/ROCKET, TinyCNN fallback)
→ small-sample-model-benchmarker
→ uncertainty-external-validation-auditor
```

## Typical DPU literature-data sequence

```text
materials-data-lineage-auditor (paper/formulation/batch hierarchy)
→ polymer-formulation-featurizer
→ validation-protocol-freezer (leave-one-paper-out)
→ model-execution-contract-builder
→ PyMC/GPR/PySR risk screening
→ small-sample-model-benchmarker
→ mechanism-claim-auditor
```
