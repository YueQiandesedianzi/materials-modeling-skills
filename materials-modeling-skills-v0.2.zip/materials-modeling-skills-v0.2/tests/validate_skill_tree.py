#!/usr/bin/env python3
from pathlib import Path
import re, sys, json

ROOT = Path(__file__).resolve().parents[1]
TREES = [ROOT / '.claude/skills', ROOT / '.codex/skills']
REQUIRED = {'name', 'description'}


def parse_frontmatter(text):
    if not text.startswith('---\n'):
        return {}
    end = text.find('\n---\n', 4)
    if end < 0:
        return {}
    block = text[4:end]
    out = {}
    for line in block.splitlines():
        if ':' in line and not line.startswith(' '):
            k, v = line.split(':', 1)
            out[k.strip()] = v.strip().strip('"')
    return out

errors = []
sets = []
for tree in TREES:
    names = {p.name for p in tree.iterdir() if p.is_dir()}
    sets.append(names)
    for name in sorted(names):
        skill = tree / name / 'SKILL.md'
        if not skill.exists():
            errors.append(f'missing {skill}')
            continue
        text = skill.read_text(encoding='utf-8')
        fm = parse_frontmatter(text)
        missing = REQUIRED - set(fm)
        if missing:
            errors.append(f'{skill}: missing frontmatter {sorted(missing)}')
        if fm.get('name') != name:
            errors.append(f'{skill}: name mismatch {fm.get("name")} != {name}')

if sets[0] != sets[1]:
    errors.append(f'skill tree mismatch: claude-only={sorted(sets[0]-sets[1])}, codex-only={sorted(sets[1]-sets[0])}')
else:
    for name in sorted(sets[0]):
        a = ROOT / '.claude/skills' / name
        b = ROOT / '.codex/skills' / name
        afiles = {p.relative_to(a) for p in a.rglob('*') if p.is_file()}
        bfiles = {p.relative_to(b) for p in b.rglob('*') if p.is_file()}
        if afiles != bfiles:
            errors.append(f'{name}: file sets differ')
            continue
        for rel in afiles:
            if (a/rel).read_bytes() != (b/rel).read_bytes():
                errors.append(f'{name}/{rel}: content differs')

for schema in (ROOT / 'schemas').glob('*.json'):
    try:
        json.loads(schema.read_text(encoding='utf-8'))
    except Exception as exc:
        errors.append(f'{schema}: invalid json: {exc}')

if errors:
    print('\n'.join(errors))
    sys.exit(1)
print(f'PASS: {len(sets[0])} skills, mirrored trees, valid JSON schemas')
