#!/usr/bin/env python3
"""Initialize a minimal Materials Modeling Skills workspace."""
from pathlib import Path
import json
import argparse

DIRS = [
    "planning/validation", "data/raw", "data/clean", "data/registry", "data/features",
    "methods", "code", "results/experiments", "results/validation",
    "results/external_validation", "results/frozen", "experiments/next_batch",
    "claims", "paper/audits", "scratch"
]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("path", nargs="?", default=".")
    parser.add_argument("--project-id", default="materials-project")
    parser.add_argument("--domain", default="polymer_materials")
    parser.add_argument("--mode", choices=["lean", "submission"], default="lean")
    args = parser.parse_args()
    root = Path(args.path).resolve()
    for d in DIRS:
        (root / d).mkdir(parents=True, exist_ok=True)
    config = {
        "interaction_mode": "learning",
        "rigor_profile": args.mode,
        "domain_profile": args.domain,
        "mode": args.mode,
        "primary_inference_target": "unresolved",
        "implementation_target": "python",
        "random_seed": 2026
    }
    manifest = {
        "schema_version": 1,
        "project_id": args.project_id,
        "domain_profile": args.domain,
        "mode": args.mode,
        "current_gate": "R0",
        "status": "initialized",
        "inference_target": None,
        "artifacts": {},
        "allowed": {
            "feature_building": False,
            "model_training": False,
            "external_claims": False,
            "next_batch_design": False,
            "paper_claim_freeze": False
        },
        "blockers": [],
        "next_action": {"owner": "human", "skill": "materials-research-orchestrator", "reason": "inspect project state"}
    }
    (root / "planning/session_config.json").write_text(json.dumps(config, indent=2), encoding="utf-8")
    (root / "planning/research_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    print(f"Initialized: {root}")

if __name__ == "__main__":
    main()
