#!/usr/bin/env python3
"""Validate a model execution contract for obvious governance gaps."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("contract", nargs="?", default="planning/model_execution_contract.json")
    parser.add_argument("--root", default=".")
    args = parser.parse_args()

    root = Path(args.root)
    path = Path(args.contract)
    if not path.is_absolute():
        path = root / path
    if not path.exists():
        raise SystemExit(f"missing contract: {path}")

    contract = json.loads(path.read_text(encoding="utf-8"))
    errors: list[str] = []
    for key in [
        "contract_id",
        "protocol_id",
        "feature_set_id",
        "task_type",
        "targets",
        "row_id",
        "split_assignments",
        "group_keys",
        "forbidden_operations",
        "required_outputs",
        "status",
    ]:
        if key not in contract:
            errors.append(f"missing required field: {key}")

    split_path = contract.get("split_assignments")
    if split_path and not (root / split_path).exists():
        errors.append(f"split_assignments path does not exist: {split_path}")

    if not contract.get("group_keys"):
        errors.append("group_keys must not be empty")

    forbidden = set(contract.get("forbidden_operations", []))
    for op in ["random_train_test_split", "global_preprocessing_before_cv", "blind_set_tuning"]:
        if op not in forbidden:
            errors.append(f"forbidden_operations should include: {op}")

    outputs = set(contract.get("required_outputs", []))
    for output in ["run_summary.json", "fold_predictions.csv", "fold_metrics.csv"]:
        if output not in outputs:
            errors.append(f"required_outputs should include: {output}")

    if contract.get("status") == "READY" and not contract.get("allowed_model_families"):
        errors.append("READY contract should list allowed_model_families")

    if errors:
        print("\n".join(errors))
        raise SystemExit(1)
    print(f"PASS: {path}")


if __name__ == "__main__":
    main()
