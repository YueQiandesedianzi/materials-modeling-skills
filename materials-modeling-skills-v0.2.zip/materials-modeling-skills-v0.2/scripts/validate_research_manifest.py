#!/usr/bin/env python3
"""Validate a Materials Modeling research manifest."""
from __future__ import annotations

import argparse
import json
from pathlib import Path


REQUIRED_ALLOWED = [
    "feature_building",
    "model_training",
    "external_claims",
    "next_batch_design",
    "paper_claim_freeze",
]


def fail(errors: list[str]) -> None:
    if errors:
        print("\n".join(errors))
        raise SystemExit(1)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("manifest", nargs="?", default="planning/research_manifest.json")
    args = parser.parse_args()

    path = Path(args.manifest)
    errors: list[str] = []
    if not path.exists():
        fail([f"missing manifest: {path}"])

    try:
        manifest = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail([f"invalid json: {path}: {exc}"])

    for key in ["schema_version", "project_id", "domain_profile", "current_gate", "status", "allowed", "blockers", "next_action"]:
        if key not in manifest:
            errors.append(f"missing required field: {key}")

    allowed = manifest.get("allowed", {})
    if not isinstance(allowed, dict):
        errors.append("allowed must be an object")
    else:
        for key in REQUIRED_ALLOWED:
            if key not in allowed:
                errors.append(f"allowed missing: {key}")
            elif not isinstance(allowed[key], bool):
                errors.append(f"allowed.{key} must be boolean")

    current_gate = manifest.get("current_gate")
    if current_gate in {"R0", "R1", "R2"} and allowed.get("model_training"):
        errors.append("model_training cannot be true before R3 validation protocol is ready")
    if current_gate in {"R0", "R1", "R2", "R3"} and allowed.get("external_claims"):
        errors.append("external_claims cannot be true before internal validation exists")
    if current_gate not in {"R8", "R9", "R10", "R11"} and allowed.get("next_batch_design"):
        errors.append("next_batch_design should not be true before R8 validation status is known")

    next_action = manifest.get("next_action", {})
    if not isinstance(next_action, dict):
        errors.append("next_action must be an object")
    else:
        for key in ["owner", "skill", "reason"]:
            if not next_action.get(key):
                errors.append(f"next_action missing: {key}")

    fail(errors)
    print(f"PASS: {path}")


if __name__ == "__main__":
    main()
