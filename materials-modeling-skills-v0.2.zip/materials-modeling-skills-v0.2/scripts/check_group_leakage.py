#!/usr/bin/env python3
"""Detect group leakage in split assignments."""
from __future__ import annotations

import argparse
import csv
from collections import defaultdict
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("assignments", default="planning/validation/split_assignments.csv")
    parser.add_argument("--group-key", required=True, action="append", help="Group column that must not cross roles")
    parser.add_argument("--role-column", default="outer_role")
    args = parser.parse_args()

    path = Path(args.assignments)
    if not path.exists():
        raise SystemExit(f"missing assignments: {path}")

    with path.open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    if not rows:
        raise SystemExit("no rows in assignments")

    missing = [c for c in [args.role_column, *args.group_key] if c not in rows[0]]
    if missing:
        raise SystemExit(f"missing columns: {missing}")

    errors: list[str] = []
    for key in args.group_key:
        roles_by_group: dict[str, set[str]] = defaultdict(set)
        for row in rows:
            group = row.get(key, "")
            role = row.get(args.role_column, "")
            if group and role:
                roles_by_group[group].add(role)
        for group, roles in sorted(roles_by_group.items()):
            train_like = {r for r in roles if "train" in r.lower()}
            test_like = {r for r in roles if any(x in r.lower() for x in ["test", "holdout", "blind", "external"])}
            if train_like and test_like:
                errors.append(f"group leakage: {key}={group} roles={sorted(roles)}")

    if errors:
        print("\n".join(errors))
        raise SystemExit(1)
    print(f"PASS: no group leakage across {args.role_column} for {args.group_key}")


if __name__ == "__main__":
    main()
